﻿using Microsoft.AspNetCore.Mvc;
using QUOTES_UJGWAT.JokeModels;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QUOTES_UJGWAT.Controllers
{
    [Route("api/quote")]
    [ApiController]
    public class Quote : ControllerBase
    {
        // GET: api/<Quote>
        [HttpGet]
        public IActionResult Get()
        {
            FunnyDatabaseContext context = new FunnyDatabaseContext();
            return Ok(context.ShortQuotes.ToList());
        }

        // GET api/<Quote>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            FunnyDatabaseContext context = new FunnyDatabaseContext();
            var quote = (from x in context.ShortQuotes
                        where x.QuoteId == id
                        select x).FirstOrDefault();
            if (quote == null)
            {
                return NotFound("Nincs ilyen id.");
            }
            return Ok(quote);
        }

        // POST api/<Quote>
        [HttpPost]
        public void Post([FromBody] ShortQuote quote)
        {
            FunnyDatabaseContext context = new FunnyDatabaseContext();
            context.ShortQuotes.Add(quote);
            context.SaveChanges();
        }

        // PUT api/<Quote>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<Quote>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            FunnyDatabaseContext context = new FunnyDatabaseContext();
            var quotedel = (from x in context.ShortQuotes
                            where x.QuoteId == id
                            select x).FirstOrDefault();
            if (quotedel == null)
            {
                return NotFound("Nincs ilyen id.");
            }

            context.ShortQuotes.Remove(quotedel);
            context.SaveChanges();
            return Ok(quotedel);
        }
    }
}
