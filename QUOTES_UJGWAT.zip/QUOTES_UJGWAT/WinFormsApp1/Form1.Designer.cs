﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridView1 = new DataGridView();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            shortQuoteBindingSource = new BindingSource(components);
            quoteIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            quoteDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            authorDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            categoryDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            isFamousDataGridViewCheckBoxColumn = new DataGridViewCheckBoxColumn();
            yearDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            checkBox1 = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)shortQuoteBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { quoteIdDataGridViewTextBoxColumn, quoteDataGridViewTextBoxColumn, authorDataGridViewTextBoxColumn, categoryDataGridViewTextBoxColumn, isFamousDataGridViewCheckBoxColumn, yearDataGridViewTextBoxColumn });
            dataGridView1.DataSource = shortQuoteBindingSource;
            dataGridView1.Location = new Point(27, 24);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(742, 212);
            dataGridView1.TabIndex = 0;
            // 
            // textBox1
            // 
            textBox1.DataBindings.Add(new Binding("Text", shortQuoteBindingSource, "QuoteId", true));
            textBox1.Location = new Point(27, 265);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            textBox2.DataBindings.Add(new Binding("Text", shortQuoteBindingSource, "Quote", true));
            textBox2.Location = new Point(27, 294);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(399, 23);
            textBox2.TabIndex = 2;
            // 
            // textBox3
            // 
            textBox3.DataBindings.Add(new Binding("Text", shortQuoteBindingSource, "Author", true));
            textBox3.Location = new Point(27, 323);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 3;
            // 
            // textBox4
            // 
            textBox4.DataBindings.Add(new Binding("Text", shortQuoteBindingSource, "Category", true));
            textBox4.Location = new Point(27, 352);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 4;
            // 
            // textBox5
            // 
            textBox5.DataBindings.Add(new Binding("Text", shortQuoteBindingSource, "Year", true));
            textBox5.Location = new Point(27, 418);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(100, 23);
            textBox5.TabIndex = 5;
            // 
            // shortQuoteBindingSource
            // 
            shortQuoteBindingSource.DataSource = typeof(JokeModels.ShortQuote);
            // 
            // quoteIdDataGridViewTextBoxColumn
            // 
            quoteIdDataGridViewTextBoxColumn.DataPropertyName = "QuoteId";
            quoteIdDataGridViewTextBoxColumn.HeaderText = "QuoteId";
            quoteIdDataGridViewTextBoxColumn.Name = "quoteIdDataGridViewTextBoxColumn";
            // 
            // quoteDataGridViewTextBoxColumn
            // 
            quoteDataGridViewTextBoxColumn.DataPropertyName = "Quote";
            quoteDataGridViewTextBoxColumn.HeaderText = "Quote";
            quoteDataGridViewTextBoxColumn.Name = "quoteDataGridViewTextBoxColumn";
            // 
            // authorDataGridViewTextBoxColumn
            // 
            authorDataGridViewTextBoxColumn.DataPropertyName = "Author";
            authorDataGridViewTextBoxColumn.HeaderText = "Author";
            authorDataGridViewTextBoxColumn.Name = "authorDataGridViewTextBoxColumn";
            // 
            // categoryDataGridViewTextBoxColumn
            // 
            categoryDataGridViewTextBoxColumn.DataPropertyName = "Category";
            categoryDataGridViewTextBoxColumn.HeaderText = "Category";
            categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            // 
            // isFamousDataGridViewCheckBoxColumn
            // 
            isFamousDataGridViewCheckBoxColumn.DataPropertyName = "IsFamous";
            isFamousDataGridViewCheckBoxColumn.HeaderText = "IsFamous";
            isFamousDataGridViewCheckBoxColumn.Name = "isFamousDataGridViewCheckBoxColumn";
            // 
            // yearDataGridViewTextBoxColumn
            // 
            yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            yearDataGridViewTextBoxColumn.HeaderText = "Year";
            yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.DataBindings.Add(new Binding("CheckState", shortQuoteBindingSource, "IsFamous", true));
            checkBox1.Location = new Point(27, 393);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(83, 19);
            checkBox1.TabIndex = 6;
            checkBox1.Text = "checkBox1";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(checkBox1);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)shortQuoteBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private DataGridViewTextBoxColumn quoteIdDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn quoteDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn authorDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;
        private DataGridViewCheckBoxColumn isFamousDataGridViewCheckBoxColumn;
        private DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private BindingSource shortQuoteBindingSource;
        private CheckBox checkBox1;
    }
}