using WinFormsApp1.JokeModels;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        FunnyDatabaseContext context = new FunnyDatabaseContext();
        public Form1()
        {
            InitializeComponent();
            shortQuoteBindingSource.DataSource = context.ShortQuotes.ToList();
            dataGridView1.DataSource = shortQuoteBindingSource;
        }
    }
}