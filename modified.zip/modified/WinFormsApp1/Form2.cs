﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1.Models;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        //SoftengLibraryContext context = new SoftengLibraryContext();
        public Author ujSzerzo = new Author();

        public Form2()
        {
            InitializeComponent();
            //authorBindingSource.DataSource = ujSzerzo;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ujSzerzo.Name = textBox1.Text;
            ujSzerzo.BirthYear = Convert.ToInt32(textBox2.Text);
            ujSzerzo.Nationality = textBox3.Text;
          
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
        }
    }
}
