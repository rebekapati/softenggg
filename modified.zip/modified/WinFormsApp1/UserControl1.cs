﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1.Models;

namespace WinFormsApp1
{
    public partial class UserControl1 : UserControl
    {
        SoftengLibraryContext context = new SoftengLibraryContext();

        public UserControl1()
        {
            InitializeComponent();
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            Loadadat();
        }

        private void Loadadat()
        {
            var adat = from x in context.Authors
                       select x;
            authorBindingSource.DataSource = adat.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                authorBindingSource.EndEdit();
                var torles = (Author)authorBindingSource.Current;
                context.Authors.Remove(torles);
                context.SaveChanges();
                Loadadat();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Hiba: "+ ex);
            }
        }
    }
}
