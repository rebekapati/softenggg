﻿using System;
using System.Collections.Generic;

namespace softeng_ZH3.Models;

public partial class Author
{
    public int AuthorId { get; set; }

    public string Name { get; set; } = null!;

    public int? BirthYear { get; set; }

    public string Nationality { get; set; } = null!;
}
